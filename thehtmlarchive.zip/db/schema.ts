import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const categories = pgTable("archive_categories", {
  id: serial().primaryKey(),
  name: text().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const files = pgTable("archive_files", {
  id: serial().primaryKey(),
  name: text().notNull(),
  categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
  sortOrder: integer("sort_order").default(0).notNull(),
  blobKey: text("blob_key").notNull().unique(),
  size: integer().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
