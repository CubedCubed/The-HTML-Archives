ALTER TABLE "archive_files" ADD COLUMN "sort_order" integer DEFAULT 0 NOT NULL;
--> statement-breakpoint
WITH ranked AS (
  SELECT "id", ROW_NUMBER() OVER (PARTITION BY "category_id" ORDER BY "created_at", "id") - 1 AS "position"
  FROM "archive_files"
)
UPDATE "archive_files" AS f
SET "sort_order" = ranked."position"
FROM ranked
WHERE f."id" = ranked."id";
