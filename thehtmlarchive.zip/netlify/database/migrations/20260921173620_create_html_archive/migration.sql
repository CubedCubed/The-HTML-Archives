CREATE TABLE "archive_categories" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "archive_files" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"category_id" integer,
	"blob_key" text NOT NULL UNIQUE,
	"size" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "archive_files" ADD CONSTRAINT "archive_files_category_id_archive_categories_id_fkey" FOREIGN KEY ("category_id") REFERENCES "archive_categories"("id") ON DELETE SET NULL;