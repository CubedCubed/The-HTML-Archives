import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { asc, eq, isNull } from "drizzle-orm";
import { db } from "../../db/index.js";
import { categories, files } from "../../db/schema.js";

const MAX_FILE_BYTES = 2 * 1024 * 1024;
// Newly uploaded pages are commonly opened immediately, so reads must reflect writes.
const uploads = () => getStore({ name: "html-archive-files", consistency: "strong" });

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

function error(message: string, status: number) {
  return json({ error: message }, status);
}

function cleanName(value: unknown) {
  return typeof value === "string" ? value.trim().slice(0, 160) : "";
}

function looksLikeHtml(content: string) {
  return !content.includes("\0") && /<(?:html|head|body|title|meta|link|style|script|main|section|article|aside|header|footer|nav|div|span|p|h[1-6]|a|img|picture|video|audio|canvas|svg|form|input|button|label|select|textarea|table|ul|ol|li|br|hr)\b[^>]*>/i.test(content);
}

function asId(value: string | undefined) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

async function categoryExists(id: number | null) {
  if (id === null) return true;
  const found = await db.select({ id: categories.id }).from(categories).where(eq(categories.id, id)).limit(1);
  return found.length === 1;
}

export default async (req: Request) => {
  try {
    const url = new URL(req.url);
    const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);

    if (req.method === "GET" && parts[0] === "state" && parts.length === 1) {
      const [categoryRows, fileRows] = await Promise.all([
        db.select().from(categories).orderBy(asc(categories.name)),
        db.select({ id: files.id, name: files.name, categoryId: files.categoryId, sortOrder: files.sortOrder, size: files.size, createdAt: files.createdAt })
          .from(files).orderBy(asc(files.categoryId), asc(files.sortOrder), asc(files.createdAt), asc(files.id)),
      ]);
      return json({
        categories: categoryRows.map((item) => ({ ...item, created: item.createdAt.getTime() })),
        files: fileRows.map((item) => ({ ...item, created: item.createdAt.getTime() })),
      });
    }

    if (req.method === "POST" && parts[0] === "categories" && parts.length === 1) {
      const body = await req.json();
      const name = cleanName((body as { name?: unknown }).name);
      if (!name) return error("Category name is required.", 400);
      const [created] = await db.insert(categories).values({ name }).returning();
      return json({ ...created, created: created.createdAt.getTime() }, 201);
    }

    if (parts[0] === "categories" && parts.length === 2 && req.method === "DELETE") {
      const id = asId(parts[1]);
      if (!id) return error("Invalid category.", 400);
      const deleted = await db.delete(categories).where(eq(categories.id, id)).returning({ id: categories.id });
      if (!deleted.length) return error("Category not found.", 404);
      return json({ ok: true });
    }

    if (req.method === "POST" && parts[0] === "files" && parts.length === 1) {
      const body = await req.json() as { name?: unknown; categoryId?: unknown; content?: unknown };
      const name = cleanName(body.name);
      const content = typeof body.content === "string" ? body.content : "";
      const categoryId = body.categoryId === null || body.categoryId === undefined ? null : Number(body.categoryId);
      if (!name) return error("File name is required.", 400);
      if (!content) return error("The HTML file is empty.", 400);
      if (!looksLikeHtml(content)) return error("The content does not appear to contain valid HTML.", 400);
      const size = new TextEncoder().encode(content).byteLength;
      if (size > MAX_FILE_BYTES) return error("HTML files must be 2 MB or smaller.", 413);
      if (categoryId !== null && (!Number.isSafeInteger(categoryId) || !(await categoryExists(categoryId)))) {
        return error("The selected category no longer exists.", 400);
      }

      const existing = await db.select({ sortOrder: files.sortOrder }).from(files)
        .where(categoryId === null ? isNull(files.categoryId) : eq(files.categoryId, categoryId))
        .orderBy(asc(files.sortOrder));
      const sortOrder = existing.length ? Math.max(...existing.map((item) => item.sortOrder)) + 1 : 0;
      const blobKey = `pages/${crypto.randomUUID()}.html`;
      await uploads().set(blobKey, content);
      try {
        const [created] = await db.insert(files).values({ name, categoryId, sortOrder, blobKey, size }).returning();
        return json({ id: created.id, name: created.name, categoryId: created.categoryId, sortOrder: created.sortOrder, size: created.size, created: created.createdAt.getTime() }, 201);
      } catch (cause) {
        await uploads().delete(blobKey);
        throw cause;
      }
    }

    if (parts[0] === "files" && parts.length >= 2) {
      const id = asId(parts[1]);
      if (!id) return error("Invalid file.", 400);
      const [record] = await db.select().from(files).where(eq(files.id, id)).limit(1);
      if (!record) return error("File not found.", 404);

      if (req.method === "GET" && parts[2] === "source" && parts.length === 3) {
        const content = await uploads().get(record.blobKey, { type: "text" });
        if (content === null) return new Response("File content not found.", { status: 404 });
        return new Response(content as string, {
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
          },
        });
      }

      if (req.method === "GET" && parts[2] === "preview" && parts.length === 3) {
        const content = await uploads().get(record.blobKey, { type: "text" });
        if (content === null) return new Response("File content not found.", { status: 404 });
        return new Response(content as string, {
          headers: {
            "Content-Type": "text/html; charset=utf-8",
            "Content-Security-Policy": "sandbox allow-scripts allow-forms allow-modals allow-popups",
            "Referrer-Policy": "no-referrer",
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "private, no-store",
          },
        });
      }

      if (req.method === "PUT" && parts.length === 2) {
        const body = await req.json() as { name?: unknown; categoryId?: unknown };
        const changes: { name?: string; categoryId?: number | null; sortOrder?: number } = {};
        if (body.name !== undefined) {
          const name = cleanName(body.name);
          if (!name) return error("File name is required.", 400);
          changes.name = name;
        }
        if (body.categoryId !== undefined) {
          const categoryId = body.categoryId === null ? null : Number(body.categoryId);
          if (categoryId !== null && (!Number.isSafeInteger(categoryId) || !(await categoryExists(categoryId)))) {
            return error("The selected category no longer exists.", 400);
          }
          if (categoryId !== record.categoryId) {
            const siblings = await db.select({ sortOrder: files.sortOrder }).from(files)
              .where(categoryId === null ? isNull(files.categoryId) : eq(files.categoryId, categoryId))
              .orderBy(asc(files.sortOrder));
            changes.sortOrder = siblings.length ? Math.max(...siblings.map((item) => item.sortOrder)) + 1 : 0;
          }
          changes.categoryId = categoryId;
        }
        if (!Object.keys(changes).length) return error("No valid changes supplied.", 400);
        const [updated] = await db.update(files).set(changes).where(eq(files.id, id)).returning();
        return json({ id: updated.id, name: updated.name, categoryId: updated.categoryId, sortOrder: updated.sortOrder, size: updated.size, created: updated.createdAt.getTime() });
      }

      if (req.method === "PUT" && parts.length === 3 && parts[2] === "reorder") {
        const body = await req.json() as { categoryId?: unknown; fileIds?: unknown };
        const categoryId = body.categoryId === null || body.categoryId === undefined ? null : Number(body.categoryId);
        const fileIds = Array.isArray(body.fileIds) ? body.fileIds.map(Number).filter((value) => Number.isSafeInteger(value) && value > 0) : [];
        if (categoryId !== null && (!Number.isSafeInteger(categoryId) || !(await categoryExists(categoryId)))) {
          return error("The selected category no longer exists.", 400);
        }
        const current = await db.select({ id: files.id, categoryId: files.categoryId }).from(files)
          .where(categoryId === null ? isNull(files.categoryId) : eq(files.categoryId, categoryId));
        const allowed = new Set(current.map((item) => item.id));
        if (fileIds.length !== current.length || fileIds.some((id) => !allowed.has(id))) {
          return error("Invalid file order for this category.", 400);
        }
        for (let index = 0; index < fileIds.length; index++) {
          await db.update(files).set({ sortOrder: index }).where(eq(files.id, fileIds[index]));
        }
        return json({ ok: true });
      }

      if (req.method === "DELETE" && parts.length === 2) {
        await db.delete(files).where(eq(files.id, id));
        try {
          await uploads().delete(record.blobKey);
        } catch (cause) {
          console.error("Could not remove orphaned archive blob", cause instanceof Error ? cause.message : "Unknown error");
        }
        return json({ ok: true });
      }
    }

    return error("Not found.", 404);
  } catch (cause) {
    console.error("Archive request failed", cause instanceof Error ? cause.message : "Unknown error");
    return error("The archive could not complete that request.", 500);
  }
};

export const config: Config = { path: "/api/*" };
