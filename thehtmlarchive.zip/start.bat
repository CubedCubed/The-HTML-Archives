@echo off
title The HTML Archives
cd /d "%~dp0"
echo ============================================================
echo                THE HTML ARCHIVES - STARTING
echo ============================================================
echo.
echo Your sharing addresses (other devices use these):
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.*' } | ForEach-Object { Write-Host ('   http://' + $_.IPAddress + ':3000') }"
echo   http://localhost:3000   (this computer)
echo.
echo Press Ctrl+C to stop the server.
echo ------------------------------------------------------------
start "" "http://localhost:3000"
node server.js
pause
