THE HTML ARCHIVES
=================

WHAT THIS IS
A Netlify website that hosts a collection of .html files in categories.
Uploaded pages and archive information use Netlify's persistent storage,
so the collection remains available across deployments and devices.


HOW TO USE THE WEBSITE
----------------------
"+ Add Category"     make as many categories as you want (Games, Tools,
                      Art...). They sort alphabetically.
"+ Add HTML File"    pick any .html/.htm file, name it anything, choose a
                      category, save. The button never goes away, so add
                      as many as you want back to back.
"Preview"            launches that HTML in a new tab, fully rendered.
"Move"               move a file to another category via dropdown.
"Rename"             change the display name.
"Delete"             remove a file, or remove a category (its files fall
                      back to "Uncategorized").
"Search"             filter files by name as you type.

Everything added through the website is stored online and shared by visitors.


FILES
-----
public/index.html              the website
netlify/functions/archive.mts the archive API
db/                            the database schema and connection
netlify/database/migrations/  automatically applied database migrations
public/sample-page.html       a sample file to upload


HOW TO DEPLOY ON RENDER
-----------------------
1. Upload this project to a GitHub repository. Keep server.js, package.json, public/, and data/ at the repository root.
2. In Render, create a new Web Service from that GitHub repository.
3. Render can use the included render.yaml automatically, or use these settings manually:
   Build Command: ./build
   Start Command: npm start
4. Deploy. Render will run ./build, then npm start. The site will be served from public/index.html and the /api/* endpoints will run from server.js.

IMPORTANT STORAGE NOTE
----------------------
The archive API writes uploaded HTML files and archive metadata to the local data/ folder. This works while the server's filesystem is available, but Render Web Services do not provide permanent local storage for application data. A restart/redeploy can therefore reset uploaded data. For permanent shared uploads, the storage layer should be moved to a persistent external database/object-storage service.
